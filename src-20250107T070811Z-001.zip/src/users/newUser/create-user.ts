

export class CreateNewUser {
    Nombre: string;
    Apellido: string;
    email: string;
    password: string;
    rol: string;
 
}
 
 
