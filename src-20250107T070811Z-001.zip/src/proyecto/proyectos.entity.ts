import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { Company } from 'src/company/companys.entity';
import { Estudiante } from 'src/students/students.entity'; 

@Entity()
export class Proyecto {
  @PrimaryGeneratedColumn()
  id_proyecto: number;

  @Column()
  nombre_proyecto: string;

  @Column('text')
  descripcion: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  fecha_publicacion: Date;

  @ManyToOne(() => Empresa, (empresa) => empresa.proyectos)
  empresa: Empresa;

  @OneToMany(() => Estudiantes, (estudiante) => estudiante.proyecto)
  estudiantes: Estudiantes[];
}