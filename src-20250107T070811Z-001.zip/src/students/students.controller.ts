import { Controller } from "@nestjs/common";



@Controller()
export class studentsController {
  // Métodos del controlador
 


}
