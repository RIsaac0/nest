import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { Proyecto } from 'src/proyecto/proyectos.entity';

@Entity()
export class Company {
  
  @PrimaryGeneratedColumn()
  id_empresa: number;

  @Column()
  nombre_empresa: string;

  @Column()
  contacto_nombre: string;

  @Column()
  contacto_email: string;

  @Column()
  telefono: string;

  @Column()
  direccion: string;

  @OneToMany(() => Proyecto, (proyecto) => proyecto.empresa)
  proyectos: Proyecto[];
}